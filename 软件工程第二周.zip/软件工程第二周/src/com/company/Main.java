package com.company;
import java.io.*;

public class Main {

    public static void main(String[] args) {
	// write your code here
        File file1=new File("C:\\Users\\86157\\Desktop\\yq_in.txt");
        File file2=new File("yq_out.txt");
        BufferedReader br=null;
        BufferedWriter bw = null;
        String[] str=new String[666] ;
        int sum=0;
        int point=0;
        try{
            br=new BufferedReader(new InputStreamReader(new FileInputStream(file1)));
            bw=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file2)));
            while((str[sum]=br.readLine())!=null) {
                sum++;
            }
            for(int i=sum-1;i>=0;i--)
            {
                if(str[i].substring(0,3).equals(str[sum-1].substring(0,3)))
                    point++;
                else
                    break;
            }
            for(int i=0;i<sum;i++)
            {
                String province=str[i].substring(0,3);
                if(province.equals(str[sum-1].substring(0,3)))
                    break;
                bw.write(province);
                bw.newLine();
                for(int j=i;j<sum;j++)
                {
                    if(str[j].substring(0,3).equals(province))
                    {
                        if(!str[j].substring(4,7).equals("待明确"))
                        {
                            bw.write(str[j].substring(4));
                            bw.newLine();
                        }
                    }
                    else
                    {
                        bw.write(" ");
                        bw.newLine();
                        i=j+1;
                        break;
                    }
                }
            }
            bw.write(str[sum-point].substring(0,3));
            bw.newLine();
            for(int i=sum-point;i<sum;i++)
            {
                bw.write(str[i].substring(4));
                bw.newLine();
            }
            bw.close();
        }catch(FileNotFoundException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        }
    }
}

