package com.company;
import java.io.*;
import java.text.Collator;
import java.util.Locale;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Scanner in=new Scanner(System.in);
        System.out.println("请输入信息：");
        String input=in.nextLine();
        String[] Input=input.split("\\s");
        File file1=new File(Input[0]);
        File file2=new File(Input[1]);
        BufferedReader br=null;
        BufferedWriter bw = null;
        String[] str=new String[666];//存放读取的数据
        String[] name=new String[666];//存放各省名称
        int[] number=new int[999];//存放各省人数总数
        int sum=0;
        int point=0;
        int Sum=0;
        try {
            br = new BufferedReader(new InputStreamReader(new FileInputStream(file1)));
            bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file2)));
            while ((str[sum] = br.readLine()) != null) {
                sum++;
            }//读入数据
            for (int i = sum - 1; i >= 0; i--) {
                if (str[i].substring(0, 3).equals(str[sum - 1].substring(0, 3)))
                    point++;
                else
                    break;
            }//找到最后一个省的第一个市所在的位置
            for(int i=0;i<sum;i++)
            {
                for(int j=i;j<sum;j++)
                {
                    if(str[j].substring(0,3).equals(str[i].substring(0,3)))
                    {
                       for(int k=j;k<sum;k++)
                       {
                           if(str[j].substring(0,3).equals(str[k].substring(0,3))) {
                           String[] s=str[j].split("\\s");
                           String[] s1=str[k].split("\\s");
                           Collator collator = Collator.getInstance(Locale.CHINA);
                           int compare = collator.compare(s[1],s1[1]);
                               if (Integer.parseInt(s[2]) <Integer.parseInt(s1[2]) || (Integer.parseInt(s[2]) == Integer.parseInt(s1[2]) && compare>0)) {
                                   String S = str[j];
                                   str[j] = str[k];
                                   str[k] = S;
                               }
                           }
                       }
                    }
                    else
                    {
                        i=j-1;
                        break;
                    }
                }
            }//将省的内部市排序（从大到小）
            for(int i=0;i<=sum-point+1;i++)
            {
                String province = str[i].substring(0, 3);
                for(int j=i;j<sum;j++)
                {
                    if(province.equals(str[j].substring(0,3))){
                        String[] s=str[j].split("\\s");
                        name[Sum]=s[0];
                        number[Sum]=Integer.parseInt(s[2])+number[Sum];
                    }
                    else
                    {
                        i=j-1;
                        Sum=Sum+1;
                        break;
                    }
                }
            }//统计省人数
            for(int i=0;i<=Sum;i++)
            {
                for(int j=0;j<=Sum;j++)
                {
                    Collator collator = Collator.getInstance(Locale.CHINA);
                    int compare = collator.compare(name[i], name[j]);
                    if(number[i]>number[j]||(number[i]==number[j]&&compare>0))
                    {
                        int x=number[i];
                        number[i]=number[j];
                        number[j]=x;
                        String X=name[i];
                        name[i]=name[j];
                        name[j]=X;
                    }
                }
            }//进行省排序
            if (Input.length == 2){
                for (int i = 0; i <=Sum; i++) {
                    String province =name[i];
                    bw.write(province+"  "+number[i]);
                    bw.newLine();
                    for (int j = 0; j < sum; j++) {
                        if (str[j].substring(0, 3).equals(province)) {
                            if (!str[j].substring(4, 7).equals("待明确")) {
                                bw.write(str[j].substring(4));
                                bw.newLine();
                            }
                        }
                    }
                    bw.write("");
                    bw.newLine();
                }
                bw.close();
            }//不输入指定省时输出所有信息
            else if(Input.length==3)
            {
                int begin=0,end=0;
                int I = 0;
                for(int i=0;i<=Sum;i++)
                {
                    if(Input[2].equals(name[i]))
                    {
                        I=i;
                        break;
                    }
                }
                bw.write(Input[2]+" "+number[I]);
                bw.newLine();
                for(int i=0;i<sum;i++)
                {
                    if(str[i].substring(0,3).equals(Input[2])) {
                        begin = i;
                        break;
                    }
                }
                for(int i=sum-1;i>=0;i--)
                {
                    if(str[i].substring(0,3).equals(Input[2])) {
                        end = i;
                        break;
                    }
                }
                for(int j=begin;j<end;j++)
                {
                    bw.write(str[j].substring(4));
                    bw.newLine();
                }
                bw.close();
            }//指定省时输入指定省信息
        }catch(FileNotFoundException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        }
    }
}

